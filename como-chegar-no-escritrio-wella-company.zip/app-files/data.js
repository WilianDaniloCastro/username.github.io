var APP_DATA = {
  "scenes": [
    {
      "id": "0-panorama-8l6h6c9xfk0jkan_hkkgwa-2",
      "name": "panorama-8L6H6C9xfK0jkaN_hKkgwA-2",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        }
      ],
      "faceSize": 512,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 1.6501881547277613,
          "pitch": 0.021005465947038005,
          "rotation": 0,
          "target": "1-entrada"
        },
        {
          "yaw": 3.091021906095974,
          "pitch": 0.09822816873513318,
          "rotation": 0,
          "target": "5-entrad-apara-a-garagem"
        }
      ],
      "infoHotspots": [
        {
          "yaw": 1.6559539093400772,
          "pitch": 0.20439494852123197,
          "title": "Entrada de Pedestres",
          "text": "Se identifique na recepção e suba até o andar terreo"
        }
      ]
    },
    {
      "id": "1-entrada",
      "name": "Entrada",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 2048,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -0.9722788983477102,
          "pitch": 0.09024435898230898,
          "rotation": 0,
          "target": "2-360-elevador"
        }
      ],
      "infoHotspots": [
        {
          "yaw": -0.9819353190582429,
          "pitch": 0.27532609575065337,
          "title": "Entrada para CJ Corporate Center",
          "text": "Siga reto até a Continental Tower, caso fique com dúvidas peça informação ao segurança mais próximo"
        }
      ]
    },
    {
      "id": "2-360-elevador",
      "name": "360 elevador",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1000,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 1.5900192937583597,
          "pitch": 0.15674737509753278,
          "rotation": 0,
          "target": "3-escritorio_entrada"
        }
      ],
      "infoHotspots": [
        {
          "yaw": 1.6193798988953327,
          "pitch": 0.3283887744555969,
          "title": "Acesse o elevador",
          "text": "Aperte o número 26 e observe a letra que a tela indicar, a letra é referente a cabine que te levará até o andar correto"
        }
      ]
    },
    {
      "id": "3-escritorio_entrada",
      "name": "Escritorio_entrada",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 2048,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [],
      "infoHotspots": [
        {
          "yaw": -1.022153314766765,
          "pitch": 0.11309976701898172,
          "title": "Escritório Wella Company",
          "text": "Seja bem-vindo e aproveite o seu primeiro dia. Não se esqueça de cadastrar sua facial com a recepção"
        }
      ]
    },
    {
      "id": "4-entrada-da-garagem",
      "name": "entrada-da-garagem",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 1.0377250589374327,
          "pitch": 0.06414899721877987,
          "rotation": 0,
          "target": "1-entrada"
        }
      ],
      "infoHotspots": [
        {
          "yaw": 1.031427556344802,
          "pitch": 0.21644591088674225,
          "title": "Entre no estacionamento",
          "text": "Ao entrar no estacionamento, busque o elevador mais próximo e aperte o botão \"0\", para ser levado ao térreo"
        }
      ]
    },
    {
      "id": "5-entrad-apara-a-garagem",
      "name": "entrad-apara-a-garagem",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 0.6541490963832501,
          "pitch": 0.12544739336853894,
          "rotation": 0,
          "target": "4-entrada-da-garagem"
        }
      ],
      "infoHotspots": [
        {
          "yaw": 0.46616369936073987,
          "pitch": 0.1649902577967559,
          "title": "Entrada para estacionamento",
          "text": "Acesse essa entrada e se mantenha a esquerda, seguindo a seta que indica \"Condôminos\""
        }
      ]
    }
  ],
  "name": "Como chegar no Escritório Wella Company",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": true,
    "fullscreenButton": false,
    "viewControlButtons": false
  }
};
